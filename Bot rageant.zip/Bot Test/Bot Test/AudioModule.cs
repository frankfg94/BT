﻿using System.Threading.Tasks;
using Discord.Commands;
using Discord.Audio;
using Discord;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Collections;

public class AudioModule : ModuleBase<ICommandContext>
{
    // Scroll down further for the AudioService.
    // Like, way down
    private readonly AudioService _service;

    // Remember to add an instance of the AudioService
    // to your IServiceCollection when you initialize your bot
    public AudioModule(AudioService service)
    {
        _service = service;
    }

    // You *MUST* mark these commands with 'RunMode.Async'
    // otherwise the bot will not respond until the Task times out.
    [Command("join", RunMode = RunMode.Async)]
    public async Task JoinCmd()
    {
        await ReplyAsync("J'ai détecté votre commande, je ne peux pas vous dire si l'audio fonctionne pour le moment");
        await _service.JoinAudio(Context.Guild, (Context.User as IVoiceState).VoiceChannel);
    }

    [Command("teststuff", RunMode = RunMode.Async)]
    public async Task TestStuff(string path = @"D:\d.wav", IVoiceChannel channel = null)
    {
        await ReplyAsync("Starting...");
        if (path == null) return;
        channel = channel ?? (Context.User as IVoiceState)?.VoiceChannel;
        if (channel == null)
        {
            await ReplyAsync("You are not in a voice channel!");
            return;
        }
        var audioClient = await channel.ConnectAsync();
        await ReplyAsync("Connexion : " + audioClient.ConnectionState);
        await SendASync(audioClient, path);
    }
    private Process CreateStream(string path)
    {
        ProcessStartInfo ffmpeg = new ProcessStartInfo
        {
            FileName = "ffmpeg.exe",
            //Arguments = $""
            Arguments = $"-i {path} -ac 2 -f s16le -ar 48000 pipe:1",
            UseShellExecute = false,
            RedirectStandardInput = true,
        };
        return Process.Start(ffmpeg);
    }

    private async Task SendASync(IAudioClient client, string path)
    {
        Process ffmpeg = CreateStream(path);
        Stream output = ffmpeg.StandardOutput.BaseStream;
        AudioOutStream discord = client.CreateDirectPCMStream(AudioApplication.Mixed,1920);
        //await discord.FlushAsync();
        await output.CopyToAsync(discord);
        await discord.FlushAsync();
        await ReplyAsync("Finished");
    }

    // Remember to add preconditions to your commands,
    // this is merely the minimal amount necessary.
    // Adding more commands of your own is also encouraged.
    [Command("leave", RunMode = RunMode.Async)]
    public async Task LeaveCmd()
    {
        await _service.LeaveAudio(Context.Guild);
    }

    [Command("play", RunMode = RunMode.Async)]
    public async Task PlayCmd([Remainder] string song)
    {
        await ReplyAsync("Vous voulez jouer de l'audio! c'est parti :smiley: ");
        await _service.SendAudioAsync(Context.Guild, Context.Channel, song);
    }
}