﻿using System;
using System.Collections.Generic;
using System.Text;
using Discord;
using Discord.Commands;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Drawing;

namespace Bot_Test
{
    public class Ping : ModuleBase<SocketCommandContext>
    {

        async Task<int> LoadDataAsync()
        {
            await Task.Delay(2000);
            return 42;
        }

        [Command("a")]
         public async Task ObtainTheFileAsync()
        {
            await ReplyAsync("Je vous ai ouvert une fenêtre");
            var progressForm = new Form()
            {
                Width = 300,
                Height = 200,
                Text = "Charger un fichier... "
                
                
            };
            TextBox txtBox = new TextBox();
            txtBox.Location = new Point(10, 50);
             txtBox.Visible = true;
            progressForm.Controls.Add(txtBox);
            var progressFormTask = progressForm.ShowDialog();      

            var data = await LoadDataAsync();

            progressForm.Close();

            MessageBox.Show(data.ToString());


        }


        [Command("ping")]
        public async Task ping()    
        {
            await ReplyAsync("Hello World");
           

        }
        [Command("note")]
        public async Task note(string s)
        {
            Random random = new Random();
            await Context.Channel.SendMessageAsync("Note : " + random.Next(0,11)+" / 10");
        }

    }

}
