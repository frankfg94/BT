﻿using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Discord;
using Discord.WebSocket;
using Discord.Audio;
using Discord.Commands;

public class AudioService
{
    private readonly ConcurrentDictionary<ulong, IAudioClient> ConnectedChannels = new ConcurrentDictionary<ulong, IAudioClient>();

    public async Task JoinAudio(IGuild guild, IVoiceChannel channel)
    {
        try
        {
            IAudioClient client;
            if (ConnectedChannels.TryGetValue(guild.Id, out client))
            {
                Console.WriteLine("1");
                return;
            }
            if (channel.Guild.Id != guild.Id)
            {
                Console.WriteLine("2");
                return;
            }

            if (channel == null)
            {
                Console.WriteLine("You need to be in a voice channel, or pass one as an argument.");
                return;
            }
        
            IAudioClient audioClient = await channel.ConnectAsync();

            if (ConnectedChannels.TryAdd(guild.Id, audioClient))
            {
                // If you add a method to log happenings from this service,
                // you can uncomment these commented lines to make use of that.
                //Console.WriteLine("Connected to voice on {0}.", guild.Name);
                Console.WriteLine(" La connexion été effectuée sur " + guild.Name);
            }
            PropertyInfo[] infos = audioClient.GetType().GetProperties();
            foreach(var i in infos)
            {
                Console.WriteLine(i.Name + " : " + i.GetValue(audioClient,null));
            }
            cli = audioClient;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
        }
    }

    IAudioClient cli;
    public async Task LeaveAudio(IGuild guild)
    {
        IAudioClient client;
        if (ConnectedChannels.TryRemove(guild.Id, out client))
        {
            await client.StopAsync();
            //await Log(LogSeverity.Info, $"Disconnected from voice on {guild.Name}.");
        }
    }




    public async Task SendAudioAsync(IGuild guild, IMessageChannel channel, string path)
    {
        // Your task: Get a full path to the file if the value of 'path' is only a filename.
        if (!File.Exists(path))
        {
           
            // Ne fonctionne que si libopus et libsodium sont correctement installés
            await channel.SendMessageAsync(" >> Le fichier n'existe pas à : " + path);
            return;
        }

        // idée : prendre une ancienne version de ffmpeg car je crois que ffmpeg fait tt buguer
        // idée 2 : afficher toutes les variables de la classe
        if (ConnectedChannels.TryGetValue(guild.Id, out IAudioClient client))
        {
            // await channel.SendMessageAsync("Lancement du fichier Audio en cours...");
            //await Log(LogSeverity.Debug, $"Starting playback of {path} in {guild.Name}");


            var output = CreateStream(path).StandardOutput.BaseStream;
            using (var stream = cli.CreateDirectPCMStream(AudioApplication.Music))
            {
                try {await output.CopyToAsync(stream); Console.WriteLine("CopyToAsync() terminé"); }
                finally{await stream.FlushAsync(); Console.WriteLine("FlushAsync()");}
                Console.WriteLine("Execution terminée");
            }
        }   
        else 
             await channel.SendMessageAsync("Navré, je n'arrive pas à accéder au système Audio");
    }

    private Process CreateStream(string path)
    {
            Console.WriteLine("Création d'un stream {" + path+ "}");
       // System.Diagnostics.Process.Start(path); 
       // Cette ligne sert à montrer que le système de path est correct
        return Process.Start(new ProcessStartInfo
        {
            FileName = "ffmpeg.exe",
            Arguments = $"-hide_banner -loglevel panic -i {path} -ac 2 -f s16le -ar 48000 pipe:1",
            UseShellExecute = false,
            RedirectStandardOutput = true
        });
    }
}